import re
from java.awt import Robot
# Lembrar de tirar as funcoes wait() ou dimunuir seus tempos
# https://pushpaproject.com
Settings.MinSimilarity = 0.9

lista = [] # Start as the empty list

RegCPF = Region(18,239,7,8)
RegRG = Region(30,307,6,9)
RegEndereco = Region(144,465,7,15)
RegFAA = Region(13,402,7,9)
RegLocal1 = Region(794,339,17,16)
RegLocal2 = Region(800,376,20,22)

RegLocal3 = Region(800,424,8,18)

RegLocal4 = Region(798,467,15,15)
RegLocal5 = Region(797,505,7,18)
RegLocal6 = Region(795,549,8,21)
RegLocal7 = Region(797,592,12,14)
RegLocal8 = Region(795,634,13,17)
RegLocalTopo = Region(791,294,14,22)
listacpLocais = []
listacpLocais.append(RegLocal1.getTopLeft().offset(5,5)) # select a pixel, that has the background color
listacpLocais.append(RegLocal2.getTopLeft().offset(5,5)) # select a pixel, that has the background color
listacpLocais.append(RegLocal3.getTopLeft().offset(5,5)) # select a pixel, that has the background color
listacpLocais.append(RegLocal4.getTopLeft().offset(5,5)) # select a pixel, that has the background color
listacpLocais.append(RegLocal5.getTopLeft().offset(5,5)) # select a pixel, that has the background color
listacpLocais.append(RegLocal6.getTopLeft().offset(5,5)) # select a pixel, that has the background color
listacpLocais.append(RegLocal7.getTopLeft().offset(5,5)) # select a pixel, that has the background color
listacpLocais.append(RegLocal8.getTopLeft().offset(5,5)) # select a pixel, that has the background color
listacpLocais.append(RegLocalTopo.getTopLeft().offset(5,5)) # select a pixel, that has the background color
cpCPF = RegCPF.getTopLeft().offset(5,5) # select a pixel, that has the background color
cpRG = RegRG.getTopLeft().offset(5,5) # select a pixel, that has the background color
cpFAA = RegFAA.getTopLeft().offset(5,5) # select a pixel, that has the background color
cpEndereco = RegEndereco.getTopLeft().offset(5,5) # select a pixel, that has the background color
menus = [cpCPF,cpRG,RegEndereco,cpFAA]
def pegarCores(banana):
    hover(banana)
    r = Robot()
    c = r.getPixelColor(banana.x, banana.y) # get the color object
    crgb = ( c.getRed(), c.getGreen(), c.getBlue() ) # decode to RGB values
    print crgb
    if crgb==(255, 255, 255):
        lista.append(banana)

def pegarCores2(banana):
    r = Robot()
    c = r.getPixelColor(banana.x, banana.y) # get the color object
    crgb = ( c.getRed(), c.getGreen(), c.getBlue() ) # decode to RGB values
    print crgb
    return crgb==(255, 255, 255)

def ControlCommmands(letra):
    type(letra, KeyModifier.CTRL)
    type(letra, KeyModifier.CTRL)
    type(letra, KeyModifier.CTRL)  

def EscreverOqueFoiEncontrado(cadastro):
    string1 = 'Item procurado: '+  cadastro + ' => Foi encontrado no documento'
    popup(string1)
    wait(3)    

def EscreverOqueNaoFoiEncontrado(cadastro):
    string1 = 'Item procurado: '+  cadastro + ' => NAO FOI encontrado no documento'
    popup(string1)
    wait(3)

def vereAlinharTodaImagem():
    while not exists("1489181195644.png"):
        ControlCommmands('-')
        
def funcao1():
    dragDrop(Location(206, 320), Location(432, 315))# CADASTRO
    ControlCommmands('c')
    type(Key.F6)
    wait(3)
    cadastro = Env.getClipboard().strip()# CADASTRO
    cadastro = ''.join(e for e in cadastro if e.isalnum())
    re.sub(r'\W+', '', cadastro)
    # print (cadastro)
    dragDrop(Location(507, 207), Location(1253, 791))# SERAH O OCR
    ControlCommmands('c')# SERAH O OCR
    wait(1)# SERAH O OCR
    OCRfeito = Env.getClipboard().strip()# CADASTRO
    OCRfeito = ''.join(e for e in OCRfeito if e.isalnum())# SERAH O OCR
    re.sub(r'\W+', '', OCRfeito)
    if cadastro in OCRfeito:
        EscreverOqueFoiEncontrado(cadastro)
    elif cadastro not in OCRfeito:
        EscreverOqueNaoFoiEncontrado(cadastro)
#for letter in 'o':# Para cada letra da palavra 'o'
    #click(SCREEN 
def hoverr(icons):
    for ch in icons:
        hover(ch)
        
def mapear(cadaAmarelo):
    click(cadaAmarelo)
    wait(1)
    lista2 = []
    for cadacpLocal in listacpLocais:
        if pegarCores2(cadacpLocal):
            hover(cadacpLocal)
            lista2.append(cadacpLocal)
    for cadacpLocal in lista2:
        click(cadacpLocal)
        funcao1()
        
contador = 1
while True:
    type(Key.F5)
    wait(3)
    for cada in menus:
        pegarCores(cada)
    print lista
    for cadaAmarelo in lista:
        mapear(cadaAmarelo)
    
    exit(-1)
    contador = contador + 1
    wait("1489181331233.png",99999)
    if (contador%3==0):
        if exists("1489184055956.png"):
            click(getLastMatch())
    
    