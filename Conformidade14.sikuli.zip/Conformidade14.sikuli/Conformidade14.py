import re
from random import randint
from java.awt import Robot
# Lembrar de tirar as funcoes wait() ou dimunuir seus tempos
# http://www.yourhtmlsource.com/books/reviews/dwtucss.html
Settings.MinSimilarity = 0.9
cadastro = "" # Variaveis globais mais usadas
rec=0 # Variaveis globais mais usadas
rec2=0 # Variaveis globais mais usadas
lista = [] # Variaveis globais mais usadas
RegCADASTRO = Region(390,157,56,87)
RegJDialog = Region(491,332,517,173)

RegCPF = Region(37,77,264,141)
RegRG = Region(118,309,146,94)
RegEndereco = Region(31,512,75,54)
RegFAA = Region(166,775,141,63)
RegLocal1 = Region(435,336,26,29)
RegLocal2 = Region(431,541,48,29)

RegLocal3 = Region(448,633,21,32)

RegLocal4 = Region(395,671,33,30)
RegLocal5 = Region(437,719,53,8)
RegLocal6 = Region(425,751,36,20)
RegLocal7 = Region(371,760,26,17)
RegLocal8 = Region(448,778,18,28)
RegLocal9 = Region(362,245,8,28)
RegLocal10 = Region(470,646,60,63)
stars = "stars.png"
listacpLocais = []
listacpLocais.append(RegLocal1.getTopLeft().offset(5,5)) # select a pixel, that has the background color
listacpLocais.append(RegLocal2.getTopLeft().offset(5,5)) # select a pixel, that has the background color
listacpLocais.append(RegLocal3.getTopLeft().offset(5,5)) # select a pixel, that has the background color
listacpLocais.append(RegLocal4.getTopLeft().offset(5,5)) # select a pixel, that has the background color
listacpLocais.append(RegLocal5.getTopLeft().offset(5,5)) # select a pixel, that has the background color
listacpLocais.append(RegLocal6.getTopLeft().offset(5,5)) # select a pixel, that has the background color
listacpLocais.append(RegLocal7.getTopLeft().offset(5,5)) # select a pixel, that has the background color
listacpLocais.append(RegLocal8.getTopLeft().offset(5,5)) # select a pixel, that has the background color
listacpLocais.append(RegLocal9.getTopLeft().offset(5,5)) # select a pixel, that has the background color
listacpLocais.append(RegLocal10.getTopLeft().offset(5,5)) # select a pixel, that has the background color
cpCPF = RegCPF.getTopLeft().offset(5,5) # select a pixel, that has the background color
cpRG = RegRG.getTopLeft().offset(5,5) # select a pixel, that has the background color
cpFAA = RegFAA.getTopLeft().offset(5,5) # select a pixel, that has the background color
cpEndereco = RegEndereco.getTopLeft().offset(5,5) # select a pixel, that has the background color
menus = [cpCPF,cpRG,RegEndereco,cpFAA]

def autoIncrement():
    global rec
    pStart = 1
    pInterval = 1
    if (rec == 0):
    	rec = pStart
    else:
    	rec = rec + pInterval
    return rec

def autoIncrement2():
    global rec2
    pStart2 = 1001
    pInterval2 = 1
    if (rec2 == 0):
    	rec2 = pStart2
    else:
    	rec2 = rec2 + pInterval2
    return rec2

def pegarCores(banana):
    global lista
    hover(banana)
    r = Robot()
    c = r.getPixelColor(banana.x, banana.y) # get the color object
    crgb = ( c.getRed(), c.getGreen(), c.getBlue() ) # decode to RGB values
    print crgb
    if crgb==(255, 255, 0):
        lista.append(banana)

def pegarCores2(banana):
    r = Robot()
    c = r.getPixelColor(banana.x, banana.y) # get the color object
    crgb = ( c.getRed(), c.getGreen(), c.getBlue() ) # decode to RGB values
    print crgb
    return crgb==(255, 255, 0)

def ControlCommmands(letra):
    type(letra, KeyModifier.CTRL)
    type(letra, KeyModifier.CTRL)
    type(letra, KeyModifier.CTRL)  

def vereAlinharTodaImagem():
    while not exists("1489181195644.png"):
        ControlCommmands('-')
        
def funcao1():
    global cadastro
    dragDrop(Location(338, 349), Location(475, 349))# CADASTRO
    ControlCommmands('c')
    icons = list( findAll(stars) )
    tamanho = len(icons)
    print 'abacate'
    print tamanho
    intt = randint(0,tamanho-1)
    doubleClick(icons[intt])
    ControlCommmands('c')
    wait(1)
    cadastro = Env.getClipboard()# CADASTRO
    cadastroLocal = cadastro.strip()# CADASTRO
    cadastroLocal = ''.join(e for e in cadastroLocal if e.isalnum())
    re.sub(r'\W+', '', cadastroLocal)
    dragDrop(Location(542, 188), Location(885, 792))# SERAH O OCR
    ControlCommmands('c')# SERAH O OCR
    wait(0.1)# SERAH O OCR
    type(Key.F6)
    wait(0.1)# (aumentar para 1 segundo)
    OCRfeito = Env.getClipboard().strip()# SERAH O OCR
    OCRfeito = ''.join(e for e in OCRfeito if e.isalnum())# SERAH O OCR
    re.sub(r'\W+', '', OCRfeito)
    click(Location(861, 47))
    if cadastroLocal in OCRfeito:
        type('Palavra <<<'+cadastro+'>>> encontrada no documento.')
    else:
        type('Palavra <<<'+cadastro+'>>> NAO ENCONTRADA no documento.')
            
#for letter in 'o':# Para cada letra da palavra 'o'
    #click(SCREEN 
        
def mapear(cadaAmarelo):
    dragDrop("1489327845771.png","1489327860155.png")# Para saber o numero de paginas
    ControlCommmands('c')# Para saber o numero de paginas
    numeroDePaginas = Env.getClipboard().strip()# Para saber o numero de paginas
    re.sub(r'\W+', '', numeroDePaginas) # Para saber o numero de paginas
    numeroDePaginas = ''.join(i for i in numeroDePaginas if i.isdigit())# Para saber o numero de paginas
    #popup(numeroDePaginas)
    nDePaginas = int(numeroDePaginas) + 0 # Conversao para int
    click(cadaAmarelo)
    wait(1)
    lista2 = []
    for cadacpLocal in listacpLocais:
        if pegarCores2(cadacpLocal):
            print autoIncrement2()
            hover(cadacpLocal)
            lista2.append(cadacpLocal)
    for cadacpLocal in lista2:
        click(cadacpLocal)
        while (nDePaginas > 0):
            funcao1()
            nDePaginas = nDePaginas - 1
            if (nDePaginas > 0):
                click(Location(1228, 46))
                ControlCommmands('a')
                ControlCommmands('x')
                wait(2)
                type('Isto vai se repetir ')
                type (str(nDePaginas))
                type(' de vezes')
                click(Location(1203, 116))# Clica no botao proxima pagina

contador = 1
while True:
    waitVanish("VdoMULTIMAGEM.png")    
    for cada in menus:
        pegarCores(cada)
    print 'tamanho da lista:'
    print len(lista)
    for cadaAmarelo in lista:
        mapear(cadaAmarelo)
    
    exit(-151)
    contador = contador + 1
    if (contador%3==0):
        if exists("1489184055956.png"):
            click(getLastMatch())
    
    