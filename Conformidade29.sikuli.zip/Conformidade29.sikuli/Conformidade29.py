import re
from random import randint
from java.awt import Robot
# Lembrar de tirar as funcoes wait() ou dimunuir seus tempos
# http://www.yourhtmlsource.com/books/reviews/dwtucss.html
Settings.MinSimilarity = 0.9
cadastro = "iniciarVariavel" # Variaveis globais mais usadas
rec=0 # Variaveis globais mais usadas
rec2=0 # Variaveis globais mais usadas
numeroDePaginas=1 # Variaveis globais mais usadas
espera=0.4 # Variaveis globais mais usadas
OCRMaior = "iniciarVariavel" # Variaveis globais mais usadas
proximaPagina = "proximaPagina.png"
maisTempo = "maisTempo.png"
voltarTodasAsPaginas = "voltarTodasAsPaginas.png"

dois = "dois.png"
quatro = "quatro.png"
cinco = "cinco.png"
seis = "seis.png"

dictNPages = {dois: 2, quatro: 4,
cinco: 5, seis: 6}


    
#paginas = [huma,dois,tres,quatro,cinco,seis,sete,oito,nove,dez,onze,doze]
Reg1 = Region(470,160,317,590)

RegLocal1 = Region(612,459,13,9)
RegLocal2 = Region(611,478,15,12)
RegLocal3 = Region(618,497,15,11)
RegLocal4 = Region(618,515,12,13)
RegLocal5 = Region(618,535,14,13)
RegLocal6 = Region(609,557,21,8)
RegLocal7 = Region(609,573,14,12)
RegLocal8 = Region(611,592,13,11)
RegLocal9 = Region(605,612,19,11)
RegLocal10 = Region(605,632,15,11)
RegLocal11 = Region(604,649,17,11)
RegLocal12 = Region(602,671,21,9)
RegLocal13 = Region(601,689,21,9)
RegLocal14 = Region(612,707,13,12)
RegLocal15 = Region(604,727,18,7)
RegLocal16 = Region(619,730,19,9)

r = Robot()
aju = [RegLocal1.getTopLeft().offset(5,5), # select a pixel, that has the background color
RegLocal1.getTopLeft().offset(5,5), # select a pixel, that has the background color
RegLocal2.getTopLeft().offset(5,5), # select a pixel, that has the background color
RegLocal3.getTopLeft().offset(5,5), # select a pixel, that has the background color
RegLocal4.getTopLeft().offset(5,5), # select a pixel, that has the background color
RegLocal5.getTopLeft().offset(5,5), # select a pixel, that has the background color
RegLocal6.getTopLeft().offset(5,5), # select a pixel, that has the background color
RegLocal7.getTopLeft().offset(5,5), # select a pixel, that has the background color
RegLocal8.getTopLeft().offset(5,5), # select a pixel, that has the background color
RegLocal9.getTopLeft().offset(5,5), # select a pixel, that has the background color
RegLocal10.getTopLeft().offset(5,5), # select a pixel, that has the background color
RegLocal11.getTopLeft().offset(5,5), # select a pixel, that has the background color
RegLocal12.getTopLeft().offset(5,5), # select a pixel, that has the background color
RegLocal13.getTopLeft().offset(5,5), # select a pixel, that has the background color
RegLocal14.getTopLeft().offset(5,5), # select a pixel, that has the background color
RegLocal15.getTopLeft().offset(5,5), # select a pixel, that has the background color
RegLocal16.getTopLeft().offset(5,5)] # select a pixel, that has the background color
nnsstt = aju[8]
protocolo = "protocolo.png"

def olharNumeroDePaginas():
    indice = seis
    for x in dictNPages:
        if Reg1.exists(Pattern(x).similar(0.7)):
            Reg1.getLastMatch().highlight(3)
            indice = x
            break
    return dictNPages[indice]

def escreverNOTXT(msg,index):
        click(Location(2757, 71))
        if index == 100:
            paste(msg+' ---- Item atual NNAAOO encontrado')
        if index == 200:
            paste(msg)
        type(Key.ENTER)

def efe6EmTodasAsPaginas(i,localx):
    global  OCRMaior
    OCR = ""
    click(localx)
    OCRfeito = ""
    popup(str(i))
    while i>0:
        click(proximaPagina)
        wait(0.4)
        type(Key.F6)
        wait(espera)
        OCRfeito = Env.getClipboard().strip()# SERAH O OCR
        OCRfeito = ''.join(e for e in OCRfeito if e.isalnum())# SERAH O OCR
        OCR = OCR + OCRfeito
        i = i - 1
    OCRfeito.replace("/", "")
    OCRfeito.replace("-", "")
    OCRfeito.replace(".", "")
    OCRMaior = OCRfeito
    click(voltarTodasAsPaginas)
    
def funcao1(local):
    global cadastro
    click(local)
    dragDrop(Location(52, 160),Location(630, 161))# CADASTRO
    ControlCommmands('c')          
    cadastro = Env.getClipboard()# CADASTRO
    if 'ONFERENCI' in cadastro:
        #escreverNOTXT(cadastro,200)
        return
    #click(nnsstt)# Neste ponto ja deve estar clicado. Soh pra garantir
    cadastroLocal = cadastro.strip()# CADASTRO
    cadastroLocal = ''.join(e for e in cadastroLocal if e.isalnum())
    re.sub(r'\W+', '', cadastroLocal)
    cadastroLocal.replace("/", "")
    cadastroLocal.replace("-", "")
    cadastroLocal.replace(".", "")
    OCRfeito = OCRMaior
    if cadastroLocal in OCRfeito:
        #escreverNOTXT(cadastro,100)
        wait(2)
        type(Key.F2)
        wait(1)
        hover(SCREEN)
        #click(Location(2313, 286))
        #type('Palavra <<<'+cadastro+'>>> encontrada no documento.')
    else:
        #escreverNOTXT(cadastro,100)
        #click(Location(2313, 286))
        #type('Palavra <<<'+cadastro+'>>> NAO ENCONTRADA no documento.')
        wait(espera)


def ControlCommmands(letra):
    type(letra, KeyModifier.CTRL)
    type(letra, KeyModifier.CTRL)
    type(letra, KeyModifier.CTRL)
    
def corAceita(banana):
    c = r.getPixelColor(banana.x, banana.y)
    crgb = ( c.getRed(), c.getGreen(), c.getBlue() )
    #(255,255,0)-> amarelo; (255,165,0) -> laranja
    boo = False
    if crgb==(255, 255, 0):
        boo = True
    if crgb==(255, 165, 0): 
        boo = True
    return boo
        
place1 = Location(322, 462)
place2 = Location(325, 485)
place3 = Location(327, 505)
place4 = Location(322, 521)

dict = {'a': aju[1], 'b': aju[2], 'c': aju[3],'d': aju[4],
'A': aju[1], 'B': aju[2], 'C': aju[3],'D': aju[4],
'E': aju[5], 'F': aju[6], 'G': aju[7], 'H': aju[8],'I': aju[9],
'J': aju[10], 'K': aju[11], 'L': aju[12],'M': aju[13],
'N': aju[14], 'P': aju[15], 'O': aju[16]}

def mapear(letrax,resultadox):
    wait(espera)
    if letrax in resultadox:
        print letrax
        controlar(dict[letrax])

def controlar(local):
    if 'o Dispon' in cadastro:
        #escreverNOTXT(cadastro,200)
        return
    nnsstt = local
    wait(1)
    funcao1(local)

# print dict['H']        
wait(protocolo,999999)
while True:
############################################################################################ 
    resultado1 = resultado2 = resultado3 = resultado4= ""
    quantidade1 = quantidade2 = quantidade3 = quantidade4 = 0
    click(place1)#CPF: apenas quatro locais
    click(voltarTodasAsPaginas)
    quantidade1 = olharNumeroDePaginas()
    if corAceita(aju[1]):
        resultado1 = resultado1+"a"
    if corAceita(aju[2]):
        resultado1 = resultado1+"b"
    if corAceita(aju[3]):
        resultado1 = resultado1+"c"
    if corAceita(aju[4]):
        resultado1 = resultado1+"d"
###################################################### 
    click(place2)#RG: apenas quatro locais
    click(voltarTodasAsPaginas)
    #quantidade2 = olharNumeroDePaginas()
    if corAceita(aju[1]):
        resultado2 = resultado2+"a"
    if corAceita(aju[2]):
        resultado2 = resultado2+"b"
    if corAceita(aju[3]):
        resultado2 = resultado2+"c"
    if corAceita(aju[4]):
        resultado2 = resultado2+"d"
############################################################
    click(place3)#Endereco: apenas quatro locais
    click(voltarTodasAsPaginas)
    #quantidade3 = olharNumeroDePaginas()
    if corAceita(aju[1]):
        resultado3 = resultado3+"a"
    if corAceita(aju[2]):
        resultado3 = resultado3+"b"
    if corAceita(aju[3]):
        resultado3 = resultado3+"c"
    if corAceita(aju[4]):
        resultado3 = resultado3+"d"
############################################################ 
    click(place4)# FAA: 15 locais
    click(voltarTodasAsPaginas)
    #quantidade4 = olharNumeroDePaginas()
    if corAceita(aju[1]):
        resultado4 = resultado4+"A"
    if corAceita(aju[2]):
        resultado4 = resultado4+"B"
    if corAceita(aju[3]):
        resultado4 = resultado4+"C"
    if corAceita(aju[4]):
        resultado4 = resultado4+"D"
    if corAceita(aju[5]):
        resultado4 = resultado4+"E"
    if corAceita(aju[6]):
        resultado4 = resultado4+"F"
    if corAceita(aju[7]):
        resultado4 = resultado4+"G"
    if corAceita(aju[8]):
        resultado4 = resultado4+"H"
    if corAceita(aju[9]):
        resultado4 = resultado4+"I"
    if corAceita(aju[10]):
        resultado4 = resultado4+"J"
    if corAceita(aju[11]):
        resultado4 = resultado4+"K"
    if corAceita(aju[12]):
        resultado4 = resultado4+"L"
    if corAceita(aju[13]):
        resultado4 = resultado4+"M"
    if corAceita(aju[14]):
        resultado4 = resultado4+"N"
    if corAceita(aju[15]):
        resultado4 = resultado4+"O"

############################################################ 
#####################################################################################
    click(place1)
    efe6EmTodasAsPaginas(quantidade1,place1)
    exit(-259)
    for letter in 'abcd':
        mapear(letter,resultado1)
    
    click(place2)
    efe6EmTodasAsPaginas(quantidade2,place2)
    for letter in 'abcd':
        mapear(letter,resultado2)
        
    click(place3)
    efe6EmTodasAsPaginas(quantidade3,place3)
    for letter in 'abcd':
        mapear(letter,resultado3)
        
    click(place4)
    efe6EmTodasAsPaginas(quantidade4,place4)
    for letter in 'ABCDEFGHIJKLMNOP':
        mapear(letter,resultado4)
