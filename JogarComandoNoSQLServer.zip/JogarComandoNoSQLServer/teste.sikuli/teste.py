intt = 1
click(Location(1011, 37))
while intt<301:
    wait("1501294019650.png")
    click("1501294019650.png")
    hover(Location(1011, 37))
    wait(2)
    intt = intt + 1