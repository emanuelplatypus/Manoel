package com;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintStream;

import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;

import org.sikuli.script.FindFailed;
import org.sikuli.script.Location;
import org.sikuli.script.Screen;

public class JogarComandoNoSQLServer {
    
    
    static String comando = "";
    
    private static String showInputDialog(String tipo) {
        String diaDoAnoGetVariable = "***N\u00daMERO DO DIA *** \n\n Inicio \n\n Qual dia inicial?";
        if (tipo=="Termino")
        		diaDoAnoGetVariable = "***N\u00daMERO DO DIA *** \n\n Termino \n\n Qual dia do t�rmino?";
        String inputValue = JOptionPane.showInputDialog(null, diaDoAnoGetVariable, "N\u00daMERO DO DIA", 1);
        if (inputValue == null || inputValue.isEmpty() || !inputValue.matches("\\d+")) {
            JOptionPane.showMessageDialog(null, "Valor inv\u00e1lido. Digite apenas algarismos de 0 a 9.");
            inputValue = showInputDialog(tipo);
        }
        return inputValue;
    }

	
	public static void main(String[] args) throws FindFailed, Exception {
    	
    	File file = new File("JogarComandoNoSQLServer_log.txt");        
        PrintStream printStreamToFile = new PrintStream(file);
        System.setOut(printStreamToFile);
        String fileName = "";
        
        JOptionPane msg = new JOptionPane("Escolha um arquivo usando a janela que aparecer� a seguir.", JOptionPane.WARNING_MESSAGE);
        final JDialog dlg = msg.createDialog("(Instru��o)");
        dlg.setDefaultCloseOperation(JDialog.DO_NOTHING_ON_CLOSE);
        new Thread(new Runnable() {
          @Override
          public void run() {
            try {
              Thread.sleep(5000);
            } catch (InterruptedException e) {
              e.printStackTrace();
            }
            dlg.setVisible(false);
          }
        }).start();
        dlg.setVisible(true);

        
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setCurrentDirectory(new File(System.getProperty("user.home")));
        int result = fileChooser.showOpenDialog(fileChooser);
        if (result == JFileChooser.APPROVE_OPTION) {
            File selectedFile = fileChooser.getSelectedFile();
            fileName = ""+selectedFile;
            System.out.println("Selected file: " + selectedFile.getAbsolutePath());
        }
        
        InputStream is = new FileInputStream(fileName);
        BufferedReader buf = new BufferedReader(new InputStreamReader(is));
        String line = buf.readLine();
        StringBuilder sb = new StringBuilder();
        
        while(line != null){
        	sb.append(line).append("\n");
        	line = buf.readLine();
        }
        comando = sb.toString();
        System.out.println("Contents : " + comando);
        buf.close();       
                
        String numero01 = showInputDialog("Inicio");
        String numero02 = showInputDialog("Termino");
        
        int diaDoAnoInicio = Integer.parseInt(numero01);
        int diaDoAnoInicioTermino = Integer.parseInt(numero02);
        Screen screen = new Screen();
        try {
        while (diaDoAnoInicio <= diaDoAnoInicioTermino) {
            
          String str1 = comando.replaceAll("variavel7410check963", ""+diaDoAnoInicio);
          //String str1 = comando;
          screen.click(new Location(792, 201));
          screen.type("a", 2);
          screen.type("x", 2);
          screen.paste(str1);
          Thread.sleep(500);
          screen.click(new Location(275, 91));
          screen.hover(new Location(908, 66));
          Thread.sleep(1500);
          diaDoAnoInicio = diaDoAnoInicio + 1 ;
        }
        
        }catch (Exception e) {
            e.printStackTrace();
        }
        }
}