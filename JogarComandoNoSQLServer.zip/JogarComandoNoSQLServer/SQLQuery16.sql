delete  from Cheques
where datepart(hh,dataHoraDoServico) <7 or datepart(hh,dataHoraDoServico) > 12