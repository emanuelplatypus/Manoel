UPDATE a
 SET a.dt_movimento=(SELECT CONVERT(VARCHAR(12),B.dataHoraDoServico, 105) FROM Cheques AS b WHERE )
 FROM  Cheques AS a
 WHERE a.dt_movimento is NULL  