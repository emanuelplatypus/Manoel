WITH x AS 
(
  SELECT TOP (SELECT MAX([qt_dade])+1 FROM Cheques) rn = ROW_NUMBER() 
  OVER (ORDER BY [object_id]) 
  FROM sys.all_columns 
  ORDER BY [object_id]
)

SELECT  *
INTO ChequesTblNormalizada
FROM 

(SELECT * FROM x
CROSS JOIN Cheques AS d
WHERE x.rn <= d.[qt_dade] 
) as algumNome
