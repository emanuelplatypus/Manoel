SELECT DISTINCT *      INTO duplicate_table
      FROM [ChequesHistorico]      

   DELETE [ChequesHistorico]
      WHERE diaDoAno
      IN (SELECT diaDoAno
             FROM duplicate_table)

   INSERT [ChequesHistorico]
      SELECT *
         FROM duplicate_table

     DROP TABLE duplicate_table
