Use BD1
Go
create function fn1
(
  @data as date
)
returns int

BEGIN
 
 return datepart(dy, @data)

END