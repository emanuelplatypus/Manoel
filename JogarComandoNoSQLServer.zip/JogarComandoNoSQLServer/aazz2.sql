CREATE TABLE tb001_clientes (
    nu_cpf varchar(11) NOT NULL UNIQUE CHECK ( nu_cpf LIKE '[0-9]{11}' and dbo.CPF_VALIDO(nu_cpf)='S' ),
    no_cliente varchar(50),
    no_endereco varchar(50),
    CONSTRAINT PK_tb001 PRIMARY KEY (nu_cpf)
);