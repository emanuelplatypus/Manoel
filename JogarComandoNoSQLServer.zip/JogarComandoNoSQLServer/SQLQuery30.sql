UPDATE Cheques
SET    qt_dade = ( abs(checksum(NewId()) % 7) ) + 1

