INSERT INTO ChequesHistorico 
SELECT *
FROM 

(select concat('C',[Empregado_ID]) as Empregado_ID

,count (case when datepart(hh,dataHoraDoServico) = 7 Then [Empregado_ID] END) as h07horas

,count (case when datepart(hh,dataHoraDoServico) = 8 Then [Empregado_ID] END) as h08horas

,count (case when datepart(hh,dataHoraDoServico) = 9 Then [Empregado_ID] END) as h09horas

,count (case when datepart(hh,dataHoraDoServico) = 10 Then [Empregado_ID] END) as h010horas

,count (case when datepart(hh,dataHoraDoServico) = 11 Then [Empregado_ID] END) as h011horas

,count (case when datepart(hh,dataHoraDoServico) >= 12 Then [Empregado_ID] END) as h012horas

,count (case when datepart(hh,dataHoraDoServico) >6 Then [Empregado_ID] END) as QtdeGeral

,count (case when [SimNao] = 'S' and datepart(hh,dataHoraDoServico) >6 Then [Empregado_ID] END)*45
+count (case when [SimNao] = 'N' and datepart(hh,dataHoraDoServico) >6 Then [Empregado_ID] END)*15 as TempoTotal

, variavel7410check963 as diaDoAno

FROM [BD1].[dbo].[ChequesTblNormalizada]

where datepart(dy,[dt_movimento]) = variavel7410check963

 GROUP BY Empregado_ID) as algumNome

