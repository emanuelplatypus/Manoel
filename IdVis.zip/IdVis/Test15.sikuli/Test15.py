from datetime import datetime
globalOCR = ""

d21CHEQUE = ["logoBB.png","nomeUNICRED.png","logoUNICRED.png","nomeBRADESCO.png","logoBRADESCO.png"]
d11ENVELOPE = ["Maximo.png","semdobrar.png"]
d22TDC = ["AsiglaTDC.png","AsiglaRCC.png"]
regDoc = Region(107,171,764,430)
faixaOCR = "faixaOCR.png"

def proximoPasso(x):
    global globalOCR
    doubleClick(Location(208, 561))
    type('c', KeyModifier.CTRL)
    boo = True
    str = Env.getClipboard().strip()
    str = str.replace("deg", "")
    str = globalOCR + str
    popup(x+' encontrado apos '+str+' rotacoes.')
    if exists(faixaOCR):
        click(Pattern(faixaOCR).targetOffset(2,49))
        paste(str)
    #exit(-11)
    
def procurar():
    global globalOCR
    #type(Key.F6)
    #sleep(1)
    globalOCR = Env.getClipboard()+'xvbvnngh'
    for x in d21CHEQUE:
        if regDoc.exists(x):
            proximoPasso(x)
    for x in d11ENVELOPE:
        if regDoc.exists(x):
            proximoPasso(x)
    for x in d22TDC:
        if regDoc.exists(x):
            proximoPasso(x)

            
click(Location(1153, 98))
type(Key.F5)
while not boo:
    procurar()

print datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        