import math
import difflib
from random import randint
from datetime import datetime
from java.awt import Robot

reg = Region(400,318,640,256)
balizaCHEQUE = []
balizaENVELOPE = []
balizaTDC = []
int1 = 0
int2 = 0
rec1=0
rec2=0
emX = 450

def cosine_similarity(v1,v2):
    sumxx, sumxy, sumyy = 0, 0, 0
    for i in range(len(v1)):
        x = v1[i]; y = v2[i]
        sumxx += x*x
        sumyy += y*y
        sumxy += x*y
    if sumxy>0:
        return sumxy/math.sqrt(sumxx*sumyy)
    else:
        return -1


def autoIncrement1():
    global rec1
    pStart = 1 #adjust start value, if req'd
    pInterval = 1 #adjust interval value, if req'd
    if (rec1 == 0):
        rec1 = pStart
    else:
        rec1 = rec1 + pInterval
    return rec1

def autoIncrement2():
    global rec2
    pStart = 1 #adjust start value, if req'd
    pInterval = 5 #adjust interval value, if req'd
    if (rec2 == 0):
        rec2 = pStart
    else:
        rec2 = rec2 + pInterval
    return rec2

def pegarCorDoFundo(banana):
    r = Robot()
    c = r.getPixelColor(banana.x, banana.y) # get the color object
    crgb = ( c.getRed(), c.getGreen(), c.getBlue() ) # decode to RGB values
    return crgb==(0, 0, 0)

ModeloCHEQUE = [5, 6, 8, 7, 6, 7, 8, 8, 7, 8, 9, 9, 10, 8]
ModeloENVELOPE = [91, 92, 92, 92, 92, 103, 123, 124, 121, 132, 188, 193, 187, 172]
ModeloTDC = [3, 3, 11, 18, 12, 14, 11, 11, 1, 0, 0, 0, 0, 0]

#print len(ModeloCHEQUE)
#print len(ModeloENVELOPE)
#print len(ModeloTDC)

def pegarDoXLS():
    text_file = open("C:\Users\manoe\Desktop\XLS\Re5sults.xls", 'r')
    yourResult = [line.split(',') for line in text_file.readlines()]
    print 'sadsada'
    print len(yourResult)

def salvarAnalisesEmTXT():    
    nome = '(Numero)PNG'
    print (nome)
    antes = datetime.now()
    print (antes)
    #locTestarCheque
    #locTestarEnv
    #locTestarTD    
    eixoY(Location(411, 545),14,'CHEQUE')  
    eixoY(Location(623, 384),14,'ENVELOPE')    
    eixoY(Location(567, 319),14,'TDC')
    
    print (ModeloCHEQUE)
    print (ModeloENVELOPE)
    print (ModeloTDC)
    print '---------------'
    print (balizaCHEQUE)
    print (balizaENVELOPE)
    print (balizaTDC)
    
    print len(balizaCHEQUE)
    print len(balizaENVELOPE)
    print len(balizaTDC)

    sm1 = difflib.SequenceMatcher(None, ModeloCHEQUE, balizaCHEQUE)
    sm2 = difflib.SequenceMatcher(None, ModeloENVELOPE, balizaENVELOPE)
    sm3 = difflib.SequenceMatcher(None, ModeloTDC, balizaTDC)

    print 'Cosine:', cosine_similarity(ModeloCHEQUE, balizaCHEQUE)
    print 'Cosine:', cosine_similarity(ModeloENVELOPE, balizaENVELOPE)
    print 'Cosine:', cosine_similarity(ModeloTDC, balizaTDC)
    print (' ')
    print 'Ratio:', sm1.ratio()
    print 'Ratio:', sm2.ratio()
    print 'Ratio:', sm3.ratio()
    print (str(datetime.now()-antes))

print 'asdsdfsff'
pegarDoXLS()
#salvarAnalisesEmTXT()
