﻿var chart = AmCharts.makeChart("chartdiv", {
  "type": "serial",
  "startDuration": 4,
  "dataProvider": [{
    "country": "cp po",
    "visits": 78,
    "color": "#FF0F00"
  }, {
    "country": "lpç",
    "visits": 77,
    "color": "#FF6600"
  }, {
    "country": "qq--",
    "visits": 91,
    "color": "#FF9E01"
  }, {
    "country": "a-",
    "visits": 88,
    "color": "#B0DE09"
  }, {
    "country": "cp ara",
    "visits": 98,
    "color": "#04D215"
  }, {
    "country": "d1-",
    "visits": 100,
    "color": "#0D8ECF"
  }, {
    "country": "235--",
    "visits": 100,
    "color": "#0D52D1"
  }, {
    "country": "jik",
    "visits": 100,
    "color": "#2A0CD0"
  }, {
    "country": "d9xb",
    "visits": 69,
    "color": "#8A0CCF"
  }, {
    "country": "A tecla F8",
    "visits": 94,
    "color": "#CD0D74"
  }, {
    "country": "zz--",
    "visits": 98,
    "color": "#754DEB"
  }, {
    "country": "w-",
    "visits": 71,
    "color": "#DDDDDD"
  }, {
    "country": "A tecla F9",
    "visits": 97,
    "color": "#999999"
  }],
  "valueAxes": [{
    "position": "left",
    "axisAlpha": 0,
    "gridAlpha": 0
  }],
  "graphs": [{
    "balloonText": "[[category]]: <b>[[value]]</b>",
    "colorField": "color",
    "fillAlphas": 0.85,
    "lineAlpha": 0.1,
    "type": "column",
    "topRadius": 1,
    "valueField": "visits"
  }],
  "depth3D": 40,
  "angle": 30,
  "chartCursor": {
    "categoryBalloonEnabled": false,
    "cursorAlpha": 0,
    "zoomable": false
  },
  "categoryField": "country",
  "categoryAxis": {
    "gridPosition": "start",
    "axisAlpha": 0,
    "gridAlpha": 0

  },
  "exportConfig": {
    "menuTop": "20px",
    "menuRight": "20px",
    "menuItems": [{
      "icon": '/lib/3/images/export.png',
      "format": 'png'
    }]
  }
}, 0);

jQuery('.chart-input').off().on('input change', function() {
  var property = jQuery(this).data('property');
  var target = chart;
  chart.startDuration = 0;

  if (property == 'topRadius') {
    target = chart.graphs[0];
  }

  target[property] = this.value;
  chart.validateNow();
});