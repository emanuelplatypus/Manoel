import re
from random import randint
from java.awt import Robot
# Lembrar de tirar as funcoes wait() ou dimunuir seus tempos
# http://www.yourhtmlsource.com/books/reviews/dwtucss.html
Settings.MinSimilarity = 0.9
cadastro = "iniciarVariavel" # Variaveis globais mais usadas
rec=0 # Variaveis globais mais usadas
rec2=0 # Variaveis globais mais usadas
numeroDePaginas=1 # Variaveis globais mais usadas

proximaPagina = "proximaPagina.png"
#huma = 
duas = "duas.png"
seis = "seis.png"
#paginas = [huma,dois,tres,quatro,cinco,seis,sete,oito,nove,dez,onze,doze]

RegLocal1 = Region(521,457,111,12)
RegLocal2 = Region(515,479,120,9)
RegLocal3 = Region(518,495,111,15)
RegLocal4 = Region(551,495,26,8)
RegLocal5 = Region(539,512,26,7)
RegLocal6 = Region(558,546,33,10)
RegLocal7 = Region(571,563,25,14)
RegLocal8 = Region(583,620,33,10)
RegLocal9 = Region(577,604,19,12)
RegLocal10 = Region(580,674,21,10)
RegLocal11 = Region(85,99,127,30)
RegLocal12 = Region(67,146,132,51)
RegLocal13 = Region(187,225,28,57)
RegLocal14 = Region(268,103,9,50)
RegLocal15 = Region(292,81,40,29)
RegLocal16 = Region(190,96,41,43)
r = Robot()

aju = [RegLocal1.getTopLeft().offset(5,5), # select a pixel, that has the background color
RegLocal1.getTopLeft().offset(5,5), # select a pixel, that has the background color
RegLocal2.getTopLeft().offset(5,5), # select a pixel, that has the background color
RegLocal3.getTopLeft().offset(5,5), # select a pixel, that has the background color
RegLocal4.getTopLeft().offset(5,5), # select a pixel, that has the background color
RegLocal5.getTopLeft().offset(5,5), # select a pixel, that has the background color
RegLocal6.getTopLeft().offset(5,5), # select a pixel, that has the background color
RegLocal7.getTopLeft().offset(5,5), # select a pixel, that has the background color
RegLocal8.getTopLeft().offset(5,5), # select a pixel, that has the background color
RegLocal9.getTopLeft().offset(5,5), # select a pixel, that has the background color
RegLocal10.getTopLeft().offset(5,5), # select a pixel, that has the background color
RegLocal1.getTopLeft().offset(5,5), # select a pixel, that has the background color
RegLocal2.getTopLeft().offset(5,5), # select a pixel, that has the background color
RegLocal3.getTopLeft().offset(5,5), # select a pixel, that has the background color
RegLocal4.getTopLeft().offset(5,5), # select a pixel, that has the background color
RegLocal5.getTopLeft().offset(5,5), # select a pixel, that has the background color
RegLocal6.getTopLeft().offset(5,5)] # select a pixel, that has the background color
nnsstt = aju[8]
protocolo = "protocolo.png"

def pegarNumDePaginas():
    if exists(duas):
        numeroDePaginas = 2
    #elif exists(seis):
        #numeroDePaginas = 6
        
def controlar(local):
    global numeroDePaginas
    click(local)
    nnsstt = local
    wait(2)
    contador = 1
    pegarNumDePaginas()
    contador = numeroDePaginas
    while contador>0:
        funcao1()
        contador = contador - 1

def funcao1():
    global cadastro
    dragDrop(Location(524, 176), Location(612, 182))# CADASTRO
    ControlCommmands('c')          
    cadastro = Env.getClipboard()# CADASTRO
    cadastroLocal = cadastro.strip()# CADASTRO
    cadastroLocal = ''.join(e for e in cadastroLocal if e.isalnum())
    re.sub(r'\W+', '', cadastroLocal)
    cadastroLocal.replace("/", "")
    type(Key.F6)
    wait(2)
    ################################################
    type(Key.WIN)
    wait(1)
    click(Location(525, 631))
    wait(2)
    if exists("1489633797312.png"):
        click(getLastMatch())
        wait("1489633866166.png")
        doubleClick(getLastMatch())
        wait(1)
        click(Location(910, 268))
        ControlCommmands('a')
        ControlCommmands('c')
        click(Location(1324, 16))
    #####################################################    
    wait(2)
    OCRfeito = Env.getClipboard().strip()# SERAH O OCR
    OCRfeito = ''.join(e for e in OCRfeito if e.isalnum())# SERAH O OCR
    re.sub(r'\W+', '', OCRfeito)
    if cadastroLocal in OCRfeito:
        click(nnsstt)
        wait(2)
        type(Key.F2)
        click(Location(929, 45))
        type('Palavra <<<'+cadastro+'>>> encontrada no documento.')
    else:
        type('Palavra <<<'+cadastro+'>>> NAO ENCONTRADA no documento.')
    wait(2)
    click(proximaPagina)

def ControlCommmands(letra):
    type(letra, KeyModifier.CTRL)
    type(letra, KeyModifier.CTRL)
    type(letra, KeyModifier.CTRL)
    
def corAceita(banana):
    c = r.getPixelColor(banana.x, banana.y)
    crgb = ( c.getRed(), c.getGreen(), c.getBlue() )
    return crgb==(142, 204, 86) or crgb==(255, 255, 238) or crgb==(51, 153, 255)
        
place1 = Location(273, 423)
place2 = Location(278, 482)
place3 = Location(313, 502)
place4 = Location(320, 522)


dict = {'a': aju[1], 'b': aju[2], 'c': aju[3],'d': aju[4],
'A': aju[1], 'B': aju[2], 'C': aju[3],'D': aju[4],
'F': aju[5], 'G': aju[6], 'H': aju[7],'I': aju[8],
'J': aju[9], 'K': aju[10], 'L': aju[11],'M': aju[12],
'N': aju[13], 'P': aju[14], 'O': aju[15],'P': aju[16]}

def bicicleta(localx,letrax,resultadox):
    click(localx)
    wait(1)
    if letrax in resultadox:
        print letrax
        controlar(dict[letrax])
# print dict['H']
wait(protocolo,999999)
while True:
############################################################################################ 
    resultado1 = resultado2 = resultado3 = resultado4= ""
    click(place1)#CPF: apenas quatro locais
    wait(1)
    if corAceita(aju[1]):
        resultado1 = resultado1+"a"
    if corAceita(aju[2]):
        resultado1 = resultado1+"b"
    if corAceita(aju[3]):
        resultado1 = resultado1+"c"
    if corAceita(aju[4]):
        resultado1 = resultado1+"d"
###################################################### 
    click(place2)#RG: apenas quatro locais
    wait(1)
    if corAceita(aju[1]):
        resultado2 = resultado2+"a"
    if corAceita(aju[2]):
        resultado2 = resultado2+"b"
    if corAceita(aju[3]):
        resultado2 = resultado2+"c"
    if corAceita(aju[4]):
        resultado2 = resultado2+"d"
############################################################
    click(place3)#Endereco: apenas quatro locais
    wait(1)
    if corAceita(aju[1]):
        resultado3 = resultado3+"a"
    if corAceita(aju[2]):
        resultado3 = resultado3+"b"
    if corAceita(aju[3]):
        resultado3 = resultado3+"c"
    if corAceita(aju[4]):
        resultado3 = resultado3+"d"
############################################################ 
    click(place4)# FAA: 16 locais
    wait(1)
    if corAceita(aju[1]):
        resultado4 = resultado4+"A"
    if corAceita(aju[2]):
        resultado4 = resultado4+"B"
    if corAceita(aju[3]):
        resultado4 = resultado4+"C"
    if corAceita(aju[4]):
        resultado4 = resultado4+"D"
    if corAceita(aju[5]):
        resultado4 = resultado4+"E"
    if corAceita(aju[6]):
        resultado4 = resultado4+"F"
    if corAceita(aju[7]):
        resultado4 = resultado4+"G"
    if corAceita(aju[8]):
        resultado4 = resultado4+"H"
    if corAceita(aju[9]):
        resultado4 = resultado4+"I"
    if corAceita(aju[10]):
        resultado4 = resultado4+"J"
    if corAceita(aju[11]):
        resultado4 = resultado4+"K"
    if corAceita(aju[12]):
        resultado4 = resultado4+"L"
    if corAceita(aju[13]):
        resultado4 = resultado4+"M"
    if corAceita(aju[14]):
        resultado4 = resultado4+"N"
    if corAceita(aju[15]):
        resultado4 = resultado4+"O"
    if corAceita(aju[16]):
        resultado4 = resultado4+"P"
############################################################ 
#####################################################################################
    for letter in 'abcd':
        bicicleta(place1,letter,resultado1)
    for letter in 'abcd':
        bicicleta(place2,letter,resultado2)
    for letter in 'abcd':
        bicicleta(place3,letter,resultado3)
    for letter in 'ABCDEFGHIJKLMNOP':
        bicicleta(place4,letter,resultado4)

    exit(-197)