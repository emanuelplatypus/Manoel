This folder contains spelling dictionaries.

To add additional spelling dictionaries:
* Visit https://cgit.freedesktop.org/libreoffice/dictionaries/tree/
* Download the *.diff and *.aff files for the desired language and place them inside this folder
* If gImageReader is running, select "Redetect Languages" from the application menu, or restart the application
